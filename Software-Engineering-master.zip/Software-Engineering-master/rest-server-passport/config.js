module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl' : 'mongodb://localhost:27017/conFusion',
    'facebook': {
        clientID: '1767697000031142',
        clientSecret: '9c91b580dee7cfe6a938d15ab53aaf98',
        callbackURL: 'https://localhost:3443/users/facebook/callback'
    }
}
